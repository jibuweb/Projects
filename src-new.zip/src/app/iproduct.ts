// export interface IProduct{
//   id: number,
//   name: string,
//   age: number
// }
export interface IProduct {
    id: number,
    name: string,
    price: number,
    size: any,
    qty: number,
    getQty: number,
    totalItemPrice: number,
    totalPrice: number,
    imagePath: string,
    getUpdatedTotalPrice: number,
    getProductList: number
  }
  
//    export class IProduct{
//     public id: number;
//     public name: string;
//     public price: number;
//     public size: any;
//     public qty: number;
//     public getQty: number;
//     public totalItemPrice: number;
//     public totalPrice: number;
//     public imagePath: string;
//     public getUpdatedTotalPrice: number;
//     public getProductList: number;
//   }