import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mystore',
  templateUrl: './mystore.component.html',
  styleUrls: ['./mystore.component.css']
})
export class MystoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
